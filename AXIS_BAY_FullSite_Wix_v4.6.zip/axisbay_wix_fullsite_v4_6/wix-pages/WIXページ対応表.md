# Wixページ対応表 v4

- home.html → /
- city.html → /city
- rules.html → /rules
- join.html → /join
- rules--*.html → 個別ルール
