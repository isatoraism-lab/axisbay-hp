# Wix導入手順 v4

## 作成する親ページ
- `/` ホーム
- `/city` 街紹介
- `/rules` ルール
- `/join` 参加へ

## 個別ルールページ
`PAGE_INVENTORY.csv` に記載された `/rules/...` ページを作成します。

## 設置
1. Wixでページを作成します。
2. 「HTMLを埋め込む」をページ幅いっぱいに配置します。
3. `wix-pages` 内の対応HTMLを全文貼り付けます。
4. HTML内の `discordUrl`、`xUrl`、`crimeQuickReferenceUrl`、`wixBaseUrl` を設定します。
5. 埋め込み枠の高さを十分に確保します。

職業・犯罪・イベントの旧ページは作成不要です。街紹介ページ内の各セクションへ統合されています。
