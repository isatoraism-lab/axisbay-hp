window.AXIS_CONFIG = {
  discordUrl: "DISCORD_INVITE_URL_HERE",
  xUrl: "X_URL_HERE",
  connectUrl: "FIVEM_CONNECT_URL_HERE",
  oldSiteUrl: "https://axis13261.wixsite.com/axisbay-2",
  crimeQuickReferenceUrl: "CRIME_QUICK_REFERENCE_URL_HERE",
  wixBaseUrl: "WIX_SITE_URL_HERE",
  serverHours: "毎日 17:00〜翌5:00",
  ruleNotice: "ルールは継続調整中です。Discordの最新告知がある場合は、最新告知を優先してください。"
};
