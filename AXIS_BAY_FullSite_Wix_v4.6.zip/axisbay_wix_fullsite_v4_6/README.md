# AXIS BAY Full Site v4

「ホーム / 街紹介 / ルール / 参加へ」の4ページを軸にしたWix移設用サイトです。

- `index.html`: ホーム
- `about.html`: 街紹介
- `rules.html`: ルールセンター
- `join.html`: 参加へ
- `rules/`: 個別ルール
- `wix-pages/`: Wix HTML埋め込み用の単独HTML

URLは `assets/js/config.js` または各Wix単独HTML内の `AXIS_CONFIG` で設定してください。
